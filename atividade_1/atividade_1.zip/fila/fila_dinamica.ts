class Elemento {
    private valor: any;
    private proximo: Elemento;

    constructor(valor) {
        this.valor = valor;
        this.proximo = null;
    }

    getValor(): any {
        return this.valor;
    }

    getProximo(): Elemento | null {
        return this.proximo;
    }

    setProximo(proximo: Elemento): void {
        this.proximo = proximo;
    }
}

class Fila {
    private tamanhoMaximo: number;
    private fila: Elemento[];
    private inicio: Elemento | null;
    private fim: Elemento | null;

    constructor(tamanhoMaximo) {
        this.tamanhoMaximo = tamanhoMaximo;
        this.fila = [];
        this.inicio = null;
        this.fim = null;
    }

    getFila(): Elemento[] {
        return this.fila;
    }

    getInicio(): Elemento | null {
        if (this.estaVazia()) {
            throw new Error('Pilha está vazia');
        } else {
            return this.inicio;
        }
    }

    setInicio(valor): void {
        this.inicio = valor;
    }

    getFim(): Elemento | null {
        if (this.estaVazia()) {
            throw new Error('Pilha está vazia');
        } else {
            return this.fim;
        }
    }

    setFim(valor): void {
        this.fim = valor;
    }

    estaVazia(): Boolean {
        return this.fila.length === 0;
    }

    estaCheia(): Boolean {
        return this.fila.length === this.tamanhoMaximo;
    }

    push(value): void {
        if (this.estaCheia()) {
            throw new Error('Fila está cheia')
        } else {
            let anterior = this.fila.length ? this.fila[this.fila.length - 1] : null;
            let novoElemento = new Elemento(value);
            this.fila.push(novoElemento);
            this.setFim(novoElemento);
            this.setInicio(novoElemento);
            
            if (this.fila.length > 1) {
                anterior.setProximo(novoElemento);
                this.setInicio(this.fila[0]);
            }
        }
    }

    pop(): Elemento {
        if (this.estaVazia()) {
            throw new Error('Pilha está vazia');
        } else {
            let seraRemovido = this.fila[this.fila.length - 1]; 
            this.fila.pop();
            
            if (!this.estaVazia()) {
                let anterior = this.fila[this.fila.length - 1];
                anterior.setProximo(null);
                this.setFim(anterior);
            }
            return seraRemovido;
        }
    }
}

let fila = new Fila(5);

// O código abaixo retorna o erro 'Pilha está vazia'
// fila.getInicio();

console.log(fila.getFila());

fila.push(1);
console.log(fila.getFila());
fila.push(2);
console.log(fila.getFila());
fila.push(3);
console.log(fila.getFila());
fila.push(4);
console.log(fila.getFila());
fila.push(5);
console.log(fila.getFila());

// O código abaixo retorna o erro 'Pilha está cheia'
// fila.push(6);

console.log(fila.getInicio())
console.log(fila.getFim());

fila.pop();
console.log(fila.getFila());
fila.pop();
console.log(fila.getFila());
fila.push(6);
fila.pop();
console.log(fila.getFila());
fila.pop();
console.log(fila.getFila());
fila.pop();
console.log(fila.getFila());
fila.pop();
console.log(fila.getFila());

// O código abaixo retorna o erro 'Pilha está vazia'
// fila.pop();
